# Sonara patch (branding + UI)
1. Unzip into the root of the DarxTune-lite repo (merge the `app` and `scripts` folders).
2. `python scripts/apply_sonara.py`      (name, accent colour, wordmark)
3. `python scripts/apply_sonara_ui.py`   (eye-blink intro, swipe carousel, search button)
4. Open in Android Studio, let Gradle sync, then Build > Build APK(s).
Both scripts are safe to re-run and stop without changes if upstream text doesn't match.

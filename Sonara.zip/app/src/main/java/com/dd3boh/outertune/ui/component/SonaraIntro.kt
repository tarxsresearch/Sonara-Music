package com.dd3boh.outertune.ui.component

import android.view.ViewGroup
import androidx.activity.ComponentActivity
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

private val Silver = Color(0xFFB8B8B8)

/** Adds the Sonara eye-blink intro on top of the activity. It removes itself when finished. */
fun ComponentActivity.showSonaraIntro() {
    val view = ComposeView(this)
    view.setContent {
        SonaraIntro(onFinished = {
            view.post { (view.parent as? ViewGroup)?.removeView(view) }
        })
    }
    addContentView(
        view,
        ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
    )
}

@Composable
fun SonaraIntro(onFinished: () -> Unit) {
    val open = remember { Animatable(0f) }
    val look = remember { Animatable(0f) }
    val textAlpha = remember { Animatable(0f) }
    val screenAlpha = remember { Animatable(1f) }

    LaunchedEffect(Unit) {
        open.animateTo(1f, tween(450))
        repeat(2) {
            open.animateTo(0.04f, tween(110))
            open.animateTo(1f, tween(150))
            delay(170)
        }
        look.animateTo(-1f, tween(250))
        look.animateTo(1f, tween(450))
        look.animateTo(0f, tween(250))
        textAlpha.animateTo(1f, tween(500))
        delay(600)
        screenAlpha.animateTo(0f, tween(450))
        onFinished()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .alpha(screenAlpha.value)
            .background(Color.Black)
            // swallow touches while the intro is visible
            .pointerInput(Unit) { detectTapGestures { } },
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(28.dp)
        ) {
            Canvas(modifier = Modifier.size(200.dp, 110.dp)) {
                val w = size.width
                val h = size.height
                val cy = h / 2f
                // half-height of the eye; a quadratic curve peaks at half its control offset
                val a = h * 0.45f * open.value
                val eye = Path().apply {
                    moveTo(0f, cy)
                    quadraticTo(w / 2f, cy - 2f * a, w, cy)
                    quadraticTo(w / 2f, cy + 2f * a, 0f, cy)
                    close()
                }
                val irisCenter = Offset(w / 2f + look.value * w * 0.05f, cy)
                clipPath(eye) {
                    drawCircle(Silver, radius = h * 0.30f, center = irisCenter)
                    drawCircle(Color.Black, radius = h * 0.14f, center = irisCenter)
                    drawCircle(
                        Color.White.copy(alpha = 0.85f),
                        radius = h * 0.05f,
                        center = irisCenter + Offset(h * 0.08f, -h * 0.08f)
                    )
                }
                drawPath(eye, Silver, style = Stroke(width = 3.dp.toPx()))
            }
            Text(
                text = "SONARA",
                color = Color.White,
                fontSize = 30.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 8.sp,
                modifier = Modifier.alpha(textAlpha.value)
            )
            Text(
                text = "TARXS INDUSTRIES",
                color = Color(0xFF9A9A9A),
                fontSize = 11.sp,
                letterSpacing = 3.sp,
                modifier = Modifier.alpha(textAlpha.value)
            )
        }
    }
}

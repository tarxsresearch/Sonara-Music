from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def replace_once(path, old, new):
    p = ROOT / path
    if not p.exists():
        raise SystemExit(f"Missing expected source file: {path}")
    s = p.read_text(encoding="utf-8")
    if old not in s:
        if new in s:
            print(f"Already branded: {path}")
            return
        raise SystemExit(f"Could not find expected text in {path}; no changes made to that file.")
    p.write_text(s.replace(old, new, 1), encoding="utf-8")
    print(f"Updated {path}")

replace_once(
    "app/src/main/res/values/app_name.xml",
    "<string name=\"app_name\">OuterTune Lite</string>",
    "<string name=\"app_name\">Sonara</string>",
)
replace_once(
    "app/src/debug/res/values/app_name.xml",
    "<string name=\"app_name\">OuterTune Debug</string>",
    "<string name=\"app_name\">Sonara Debug</string>",
)
replace_once(
    "app/src/main/java/com/dd3boh/outertune/ui/theme/Theme.kt",
    "val DefaultThemeColor = Color(0xFFED5564)",
    "val DefaultThemeColor = Color(0xFFB8B8B8) // Sonara monochrome accent",
)
replace_once(
    "app/build.gradle.kts",
    'var outputFileName = \"OuterTune-${variant.versionName}-${output.baseName}-${output.versionCode}.apk\"',
    'var outputFileName = \"Sonara-${variant.versionName}-${output.baseName}-${output.versionCode}.apk\"',
)

home_path = ROOT / "app/src/main/java/com/dd3boh/outertune/ui/screens/HomeScreen.kt"
if not home_path.exists():
    raise SystemExit("Missing expected source file: app/src/main/java/com/dd3boh/outertune/ui/screens/HomeScreen.kt")
home = home_path.read_text(encoding="utf-8")
marker = """        ) {
            item {
                Row(
                    modifier = Modifier
                        .windowInsetsPadding(WindowInsets.systemBars.only(WindowInsetsSides.Horizontal))"""
brand = """        ) {
            item {
                androidx.compose.foundation.layout.Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 22.dp)
                        .animateItem()
                ) {
                    androidx.compose.material3.Text(
                        text = "SONARA",
                        style = MaterialTheme.typography.headlineMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    androidx.compose.material3.Text(
                        text = "YOUR MUSIC. YOUR SPACE.",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    androidx.compose.material3.Text(
                        text = "TARXS INDUSTRIES",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            item {
                Row(
                    modifier = Modifier
                        .windowInsetsPadding(WindowInsets.systemBars.only(WindowInsetsSides.Horizontal))"""
if "text = \"SONARA\"" not in home:
    if marker not in home:
        raise SystemExit("HomeScreen insertion point did not match; no HomeScreen changes made.")
    home_path.write_text(home.replace(marker, brand, 1), encoding="utf-8")
    print("Updated HomeScreen brand header")
else:
    print("HomeScreen brand header already present")

print("Branding applied. Existing LICENSE file was intentionally left untouched.")

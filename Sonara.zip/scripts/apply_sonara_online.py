"""Sonara patch for the full (online) InterTune source.
Branding + own app ID (FORKS.md rules 1-2), eye-blink intro, search button, swipe carousel.
Safe to re-run; stops without touching a file if upstream text doesn't match."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
JAVA = APP / "src/main/java/com/dd3boh/outertune"
OLD_ID, NEW_ID = "dev.skye.intertune", "com.tarxs.sonara"

def read(p):
    if not p.exists():
        raise SystemExit(f"Missing expected file: {p}")
    return p.read_text(encoding="utf-8")

def replace_once(path, old, new, label):
    s = read(path)
    if old not in s:
        if new in s:
            print(f"Already done: {label}")
            return
        raise SystemExit(f"Could not find expected text for '{label}' in {path}; no changes made to that file.")
    path.write_text(s.replace(old, new, 1), encoding="utf-8")
    print(f"Updated: {label}")

# 1. App ID everywhere except BuiltInKeys.kt (that file keeps InterTune's own id so its services stay off for forks)
changed = 0
for sub in ["src/main", "src/debug", "src/preview", "src/release"]:
    base = APP / sub
    if not base.exists():
        continue
    for f in base.rglob("*"):
        if f.suffix in (".kt", ".xml") and f.name != "BuiltInKeys.kt":
            t = f.read_text(encoding="utf-8")
            if OLD_ID in t:
                f.write_text(t.replace(OLD_ID, NEW_ID), encoding="utf-8")
                changed += 1
gradle = APP / "build.gradle.kts"
g = read(gradle)
if OLD_ID in g:
    gradle.write_text(g.replace(OLD_ID, NEW_ID), encoding="utf-8")
    changed += 1
print(f"App ID: {changed} file(s) changed to {NEW_ID}")

# 2. Names, colour, APK file name
replace_once(APP / "src/main/res/values/app_name.xml",
             '<string name="app_name">InterTune</string>', '<string name="app_name">Sonara</string>', "app name")
replace_once(APP / "src/debug/res/values/app_name.xml",
             '<string name="app_name">InterTune Debug</string>', '<string name="app_name">Sonara Debug</string>', "debug app name")
replace_once(JAVA / "ui/theme/Theme.kt",
             "val DefaultThemeColor = Color(0xFFED5564)",
             "val DefaultThemeColor = Color(0xFFB8B8B8) // Sonara monochrome accent", "accent colour")
replace_once(gradle, '"InterTune-${variant.versionName}', '"Sonara-${variant.versionName}', "APK file name")

# 3. HomeScreen: header + search button + carousel
home_p = JAVA / "ui/screens/HomeScreen.kt"
home = read(home_p)
if "SonaraCarousel(" in home:
    print("Already done: HomeScreen")
else:
    for anchor, new in [
        ("import androidx.compose.material.icons.rounded.SdCard\n", "import androidx.compose.material.icons.rounded.Search\n"),
        ("import com.dd3boh.outertune.ui.component.ScrollToTopManager\n", "import com.dd3boh.outertune.ui.component.SonaraCarousel\n"),
    ]:
        if anchor not in home:
            raise SystemExit(f"Import anchor not found: {anchor.strip()}")
        home = home.replace(anchor, anchor + new, 1)

    block = '''            item(key = "sonara_header", contentType = "sonara_header") {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .windowInsetsPadding(WindowInsets.systemBars.only(WindowInsetsSides.Horizontal))
                        .padding(start = 20.dp, end = 8.dp, top = 12.dp, bottom = 8.dp)
                        .animateItem()
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "SONARA",
                            style = MaterialTheme.typography.headlineMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "YOUR MUSIC. YOUR SPACE.",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        val surf = MaterialTheme.colorScheme.surface
                        val darkSurface = (surf.red + surf.green + surf.blue) / 3f < 0.5f
                        androidx.compose.foundation.Image(
                            painter = androidx.compose.ui.res.painterResource(
                                if (darkSurface) R.drawable.tarxs_logo_light else R.drawable.tarxs_logo
                            ),
                            contentDescription = "TARXS Industries",
                            contentScale = androidx.compose.ui.layout.ContentScale.Fit,
                            alignment = Alignment.CenterStart,
                            modifier = Modifier
                                .padding(top = 6.dp)
                                .height(18.dp)
                        )
                    }
                    androidx.compose.material3.IconButton(onClick = { navController.navigate("search") }) {
                        Icon(
                            imageVector = Icons.Rounded.Search,
                            contentDescription = stringResource(R.string.search)
                        )
                    }
                }
            }

            if (shownPicks.isNotEmpty()) {
                item(key = "sonara_carousel", contentType = "sonara_carousel") {
                    val featured = shownPicks.take(6)
                    SonaraCarousel(
                        songs = featured,
                        activeId = mediaMetadata?.id,
                        isPlaying = isPlaying,
                        onPlay = { index ->
                            val pick = featured[index]
                            if (pick.id == mediaMetadata?.id) {
                                playerConnection.togglePlayPause()
                            } else {
                                playerConnection.playQueue(YouTubeQueue.radio(pick), isRadio = true)
                            }
                        },
                        modifier = Modifier.animateItem()
                    )
                }
            }

'''
    tiles = '            item(key = "tiles", contentType = "tiles") {\n'
    if tiles not in home:
        raise SystemExit("Tiles anchor not found; no HomeScreen changes made.")
    home = home.replace(tiles, block + tiles, 1)
    home_p.write_text(home, encoding="utf-8")
    print("Updated: HomeScreen (header, search button, carousel)")

# 4. MainActivity: eye-blink intro
main_p = JAVA / "MainActivity.kt"
main = read(main_p)
if "showSonaraIntro()" in main:
    print("Already done: MainActivity")
else:
    imp = "import com.dd3boh.outertune.ui.screens.search.SearchBarContainer\n"
    anchor = "        setContent(parent = Animations.recomposer(this)) {\n            Log.v(MAIN_TAG, \"RC-1\")"
    if imp not in main or anchor not in main:
        raise SystemExit("MainActivity anchors not found; no MainActivity changes made.")
    main = main.replace(imp, imp + "import com.dd3boh.outertune.ui.component.showSonaraIntro\n", 1)
    main = main.replace(anchor,
        "        if (savedInstanceState == null) {\n"
        "            window.decorView.post { showSonaraIntro() }\n"
        "        }\n\n" + anchor, 1)
    main_p.write_text(main, encoding="utf-8")
    print("Updated: MainActivity (eye-blink intro)")

print("Sonara applied.")

"""Sonara UI patch: eye-blink intro, swipe carousel, top-right search button.
Run AFTER apply_sonara.py (it also works without it). Safe to re-run."""
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
JAVA = ROOT / "app/src/main/java/com/dd3boh/outertune"

def read(p):
    if not p.exists():
        raise SystemExit(f"Missing expected file: {p}")
    return p.read_text(encoding="utf-8")

# ---------- HomeScreen ----------
home_p = JAVA / "ui/screens/HomeScreen.kt"
home = read(home_p)

if "SonaraCarousel(" in home:
    print("HomeScreen already patched")
else:
    # imports
    for anchor, new in [
        ("import androidx.compose.material.icons.rounded.SdCard\n",
         "import androidx.compose.material.icons.rounded.Search\n"),
        ("import com.dd3boh.outertune.ui.component.ScrollToTopManager\n",
         "import com.dd3boh.outertune.ui.component.SonaraCarousel\n"),
    ]:
        if anchor not in home:
            raise SystemExit(f"Import anchor not found: {anchor.strip()}")
        home = home.replace(anchor, anchor + new, 1)

    header = '''            item {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .windowInsetsPadding(WindowInsets.systemBars.only(WindowInsetsSides.Horizontal))
                        .padding(start = 20.dp, end = 8.dp, top = 12.dp, bottom = 8.dp)
                        .animateItem()
                ) {
                    androidx.compose.foundation.layout.Column(modifier = Modifier.weight(1f)) {
                        androidx.compose.material3.Text(
                            text = "SONARA",
                            style = MaterialTheme.typography.headlineMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        androidx.compose.material3.Text(
                            text = "YOUR MUSIC. YOUR SPACE.",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        androidx.compose.material3.Text(
                            text = "TARXS INDUSTRIES",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    androidx.compose.material3.IconButton(onClick = { navController.navigate("search") }) {
                        androidx.compose.material3.Icon(
                            imageVector = Icons.Rounded.Search,
                            contentDescription = stringResource(R.string.search)
                        )
                    }
                }
            }
'''
    tiles_start = '''            item {
                Row(
                    modifier = Modifier
                        .windowInsetsPadding(WindowInsets.systemBars.only(WindowInsetsSides.Horizontal))
                        .padding(horizontal = 12.dp, vertical = 6.dp)'''
    old_brand = re.compile(
        r"            item \{\n                androidx\.compose\.foundation\.layout\.Column\(.*?\n            \}\n(?=            item \{\n                Row\()",
        re.S)
    if old_brand.search(home):
        home = old_brand.sub(lambda m: header, home, count=1)
    elif tiles_start in home:
        home = home.replace(tiles_start, header + tiles_start, 1)
    else:
        raise SystemExit("HomeScreen header anchor not found; no HomeScreen changes made.")

    carousel = '''            quickPicks?.takeIf { it.isNotEmpty() }?.let { picks ->
                item {
                    val featured = picks.take(6)
                    SonaraCarousel(
                        songs = featured,
                        activeId = mediaMetadata?.id,
                        isPlaying = isPlaying,
                        onPlay = { index ->
                            if (featured[index].id == mediaMetadata?.id) {
                                playerConnection.player.togglePlayPause()
                            } else {
                                playerConnection.playQueue(
                                    ListQueue(
                                        title = "Featured",
                                        items = featured.map { it.toMediaMetadata() },
                                        startIndex = index
                                    )
                                )
                            }
                        },
                        modifier = Modifier.animateItem()
                    )
                }
            }

'''
    qp = "            quickPicks?.takeIf { it.isNotEmpty() }?.let { quickPicks ->\n"
    if qp not in home:
        raise SystemExit("Carousel anchor not found; no HomeScreen changes made.")
    home = home.replace(qp, carousel + qp, 1)
    home_p.write_text(home, encoding="utf-8")
    print("Updated HomeScreen (header + search button + carousel)")

# ---------- MainActivity (intro) ----------
main_p = JAVA / "MainActivity.kt"
main = read(main_p)
if "showSonaraIntro()" in main:
    print("MainActivity already patched")
else:
    imp = "import com.dd3boh.outertune.ui.screens.search.SearchBarContainer\n"
    call_anchor = "        setContent {\n            Log.v(MAIN_TAG, \"RC-1\")"
    if imp not in main or call_anchor not in main:
        raise SystemExit("MainActivity anchors not found; no MainActivity changes made.")
    main = main.replace(imp, imp + "import com.dd3boh.outertune.ui.component.showSonaraIntro\n", 1)
    main = main.replace(
        call_anchor,
        "        if (savedInstanceState == null) {\n"
        "            window.decorView.post { showSonaraIntro() }\n"
        "        }\n\n" + call_anchor, 1)
    main_p.write_text(main, encoding="utf-8")
    print("Updated MainActivity (eye-blink intro)")

print("Sonara UI applied.")
